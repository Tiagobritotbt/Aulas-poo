package br.com.edu.ifg.projeto06.servico;

import br.com.edu.ifg.projeto06.vo.Fabricante;
import br.com.edu.ifg.projeto06.vo.Produto;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author danilo
 */
public class ProdutoService {

    private List<Produto> listaDeProdutos;

    public ProdutoService() {
        listaDeProdutos = new ArrayList<>();
    }

    public void adicionar() {
        Scanner sc = new Scanner(System.in);
        Produto produto = new Produto();

        System.out.println("Cadastrando produto...");

        System.out.print("Informe o código: ");
        produto.setCodigo(sc.nextInt());
        System.out.print("Insira o nome: \n");
        sc = new Scanner(System.in);
        produto.setNome(sc.nextLine());
        sc = new Scanner(System.in);
        

        System.out.print("Informe o preço: ");
        produto.setPreco(sc.nextFloat());
        System.out.print("Informe a quantidade: ");
        produto.setQuantidade(sc.nextInt());

        Fabricante fabricante = new Fabricante();
        System.out.println("Fabricante: ");
        System.out.print("CNPJ fabricante: ");
        fabricante.setCnpj(sc.nextInt());
        System.out.print("Nome fabricante: ");
        sc = new Scanner(System.in);
        fabricante.setNome(sc.nextLine());
        produto.setFabricante(fabricante);
        listaDeProdutos.add(produto);

    }

    public void remover() {
        System.out.println("Insira o codigo para remover:");
        Scanner sc = new Scanner(System.in);
        Produto produto = new Produto();
        produto.setCodigo(sc.nextInt());
        listaDeProdutos.remove(produto);
        System.out.println("\n");
    }

    public void verDetalhes(int codigo) {

    }

    public void listar() {
        for (Produto itemDaLista : listaDeProdutos) {
            System.out.println("-------: Produto :-------");
            System.out.println("Código: " + itemDaLista.getCodigo());
            System.out.println("Nome: " + itemDaLista.getNome());
            System.out.println("Fabricante: " + itemDaLista.getFabricante().getNome());
            System.out.println("Preço: " + itemDaLista.getPreco());
            System.out.println("Quantidade: " + itemDaLista.getQuantidade());
            System.out.println("------------::------------\n");
        }
    }

}
