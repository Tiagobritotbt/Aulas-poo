public class Hello {
	
	public static void main(String argumentos[])
	{
		System.out.println("Hello World... Meu primeiro programa em java.");
	}

}
