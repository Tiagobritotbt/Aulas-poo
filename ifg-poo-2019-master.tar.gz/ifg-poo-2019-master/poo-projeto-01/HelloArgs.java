public class HelloArgs {
	
	public static void main(String argumentos[])
	{

		System.out.println("Olá "+argumentos[0]);
		System.out.println(argumentos.length);
	}

}
